<?php
if (!is_admin()) return;
require_once dirname(__FILE__) . '/includes/class-bwp-option-page.php';
